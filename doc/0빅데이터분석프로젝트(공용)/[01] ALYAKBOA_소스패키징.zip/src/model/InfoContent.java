package model;

public class InfoContent {

	private String content;

	public InfoContent(String itemname, String content) {
		this.content = content;
	}

	public String getContent() {
		return content;
	}
}
