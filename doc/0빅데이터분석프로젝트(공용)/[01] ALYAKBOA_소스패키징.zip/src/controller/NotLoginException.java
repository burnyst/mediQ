package controller;

public class NotLoginException extends RuntimeException {
	private static final long serialVersionUID = 927817068060818470L;
}
