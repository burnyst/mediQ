package controller;

public class DuplicateIdException extends RuntimeException {

}