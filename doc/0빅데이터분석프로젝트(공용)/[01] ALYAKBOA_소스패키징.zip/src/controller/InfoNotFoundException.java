package controller;

public class InfoNotFoundException extends RuntimeException {

}
