package controller;

public class FaqNotFoundException extends RuntimeException {

}
