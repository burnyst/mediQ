package controller;

public class newsNotFoundException extends Exception {

}
