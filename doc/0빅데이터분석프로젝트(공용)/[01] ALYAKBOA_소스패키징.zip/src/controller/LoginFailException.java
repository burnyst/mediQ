package controller;

//p.605
//로그인 실패와 관련된 예외 처리 페이지이다.
public class LoginFailException extends RuntimeException {

}
