package controller;

public class PermissionDeniedException extends RuntimeException {

}
