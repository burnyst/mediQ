window.addEventListener("load", function() {
	document.getElementById("pre").addEventListener("click", function() {
		location.href = this.value;
	});
	document.getElementById("home").addEventListener("click", function() {
		location.href = this.value;
	});
});